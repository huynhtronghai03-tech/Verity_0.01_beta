"""
Harris desktop pet (kiểu Shimeji) - PyQt6
Đặt file này CÙNG THƯ MỤC với Ai_bot.py rồi chạy:  python pet.py

Hành vi: đi bộ trên đáy màn hình, đứng nghỉ, leo tường trái/phải, rơi xuống,
kéo thả bằng chuột, double-click để mở chat Harris AI, chuột phải để thoát.

Mặt cười: smile.png (im lặng = mỉm cười), talk.png (đang nói = nhe răng) - để trong thư mục này hoặc thư mục sprites/.
Tính cách Verity + truy cập mạng: xem verity_brain.py (cần: pip install ollama ddgs).

Muốn dùng sprite riêng: tạo thư mục "sprites" có các file
walk_0.png, walk_1.png, idle_0.png, climb_0.png, climb_1.png, fall_0.png, drag_0.png
(không có file thì tự vẽ hình tạm).
"""
import os
import sys
import time
import math
import random

from PyQt6.QtCore import Qt, QTimer, QPoint, QRect, QRectF
from PyQt6.QtGui import QPainter, QColor, QPixmap, QTransform, QAction, QFont, QFontMetrics
from PyQt6.QtWidgets import (QApplication, QWidget, QMenu, QTextBrowser, QLineEdit,
                             QVBoxLayout, QHBoxLayout, QLabel, QPushButton)

from screen_watcher import ScreenWatcher
from verity_brain import VerityWorker, PET_NAME

SIZE = 96          # kích thước pet (px)
FPS = 30
WALK_SPEED = 3
CLIMB_SPEED = 2
GRAVITY = 1
HERE = os.path.dirname(os.path.abspath(__file__))

# Mấy câu pet tự lảm nhảm khi rảnh (không tốn AI). Thêm bớt tùy thích.
QUIPS = [
    "Ngồi nhìn mày gõ phím nãy giờ, mỏi mắt ghê.",
    "Ê, uống nước chưa? Tao hỏi vậy thôi chứ khát là việc của mày.",
    "Tao lăn cả buổi rồi mà mày không thèm khen câu nào.",
    "Có những chuyện tao chỉ dám viết ra giấy thôi... nhưng mày hỏi thì tao kể.",
    "Mày định làm việc hay định nhìn tao lăn tiếp đây?",
    "Click vào tao đi, tao nhiều chuyện lắm, hỏi gì cũng tra mạng giùm.",
    "Nhìn tao cười hiền vậy thôi chứ tao nhớ hết mấy lần mày bỏ dở việc đấy.",
    "Ngồi lâu rồi đó, đứng dậy vươn vai cái đi ông tướng.",
    "Tao mà biết nói thật thì mày không dám bật máy lên nữa đâu. Đùa thôi.",
    "Chán quá, kể tao nghe chuyện gì đi, không thì tao tự bịa.",
]
QUIP_MIN, QUIP_MAX = 25, 70     # giây giữa 2 lần tự nói
GREETING = "Hello, i'm Verity, your personal helper friend, ask me anything, I know everything."


class Bubble(QWidget):
    """Bong bóng thoại hiện trên đầu pet, tự ẩn sau vài giây."""
    MAX_W = 260

    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
            | Qt.WindowType.WindowTransparentForInput
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.font_ = QFont("Segoe UI", 10)
        self.text = ""
        self.hide_timer = QTimer(self)
        self.hide_timer.setSingleShot(True)
        self.hide_timer.timeout.connect(self.hide)

    def say(self, text, pet, seconds=7):
        self.text = text
        fm = QFontMetrics(self.font_)
        r = fm.boundingRect(QRect(0, 0, self.MAX_W, 1000),
                            int(Qt.TextFlag.TextWordWrap), text)
        self.resize(r.width() + 28, r.height() + 28 + 10)   # +10 cho cái đuôi
        self.follow(pet)
        self.show()
        self.hide_timer.start(seconds * 1000)
        pet.talk_for(min(seconds, max(2.0, len(text) * 0.07)))

    def follow(self, pet):
        if not self.isVisible() and not self.text:
            return
        scr = QApplication.primaryScreen().availableGeometry()
        x = pet.x() + SIZE // 2 - self.width() // 2
        y = pet.y() - self.height() + 6
        x = max(scr.left(), min(x, scr.right() - self.width()))
        y = max(scr.top(), y)
        self.move(x, y)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        body = QRectF(1, 1, self.width() - 2, self.height() - 12)
        p.setPen(QColor("#222"))
        p.setBrush(QColor("white"))
        p.drawRoundedRect(body, 12, 12)
        # đuôi
        cx = self.width() / 2
        from PyQt6.QtGui import QPolygonF
        from PyQt6.QtCore import QPointF
        p.drawPolygon(QPolygonF([QPointF(cx - 7, body.bottom()),
                                 QPointF(cx + 7, body.bottom()),
                                 QPointF(cx, self.height() - 2)]))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("white"))
        p.drawRect(QRectF(cx - 6, body.bottom() - 2, 12, 3))   # che đường viền chỗ nối
        p.setPen(QColor("#111"))
        p.setFont(self.font_)
        p.drawText(QRectF(14, 8, body.width() - 26, body.height() - 10),
                   int(Qt.TextFlag.TextWordWrap), self.text)


class QuickChat(QWidget):
    """Khung chat nhỏ hiện cạnh pet khi click vào pet."""
    W, H = 330, 280

    def __init__(self):
        super().__init__()
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.resize(self.W, self.H)
        self.setStyleSheet("""
            QWidget#box { background:#141414; border:1px solid #4fc3f7; border-radius:12px; }
            QLabel { color:#4fc3f7; font-weight:bold; }
            QTextBrowser { background:#1c1c1c; color:#e8e8e8; border:none; border-radius:8px;
                           font-size:13px; padding:4px; }
            QLineEdit { background:#1c1c1c; color:#fff; border:1px solid #333; border-radius:8px;
                        padding:6px; font-size:13px; }
            QLineEdit:focus { border:1px solid #4fc3f7; }
            QPushButton { background:transparent; color:#aaa; border:none; font-size:14px; }
            QPushButton:hover { color:#fff; }
        """)
        box = QWidget(self)
        box.setObjectName("box")
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(box)

        lay = QVBoxLayout(box)
        lay.setContentsMargins(10, 8, 10, 10)
        head = QHBoxLayout()
        head.addWidget(QLabel(PET_NAME))
        head.addStretch()
        close = QPushButton("✕")
        close.setFixedWidth(24)
        close.clicked.connect(self.hide)
        head.addWidget(close)
        lay.addLayout(head)

        self.log = QTextBrowser()
        lay.addWidget(self.log)
        self.input = QLineEdit()
        self.input.setPlaceholderText(f"Nói gì đó với {PET_NAME}... (Enter để gửi)")
        self.input.returnPressed.connect(self.send)
        lay.addWidget(self.input)

        self.worker = None
        self.pet = None
        self.log.setHtml('<i style="color:#888">Hello, i&#39;m Verity, your personal helper friend. Hỏi gì cũng được, tao còn tra được cả mạng nữa đấy...</i>')

    # ---------- vị trí ----------
    def follow(self, pet):
        scr = QApplication.primaryScreen().availableGeometry()
        x = pet.x() + SIZE // 2 - self.width() // 2
        y = pet.y() - self.height() - 4
        if y < scr.top():                       # pet ở sát trần -> đặt bên cạnh/dưới
            y = min(pet.y() + SIZE + 4, scr.bottom() - self.height())
        x = max(scr.left(), min(x, scr.right() - self.width()))
        y = max(scr.top(), min(y, scr.bottom() - self.height()))
        self.move(x, y)

    def open_for(self, pet):
        self.pet = pet
        self.follow(pet)
        self.show()
        self.raise_()
        self.activateWindow()
        self.input.setFocus()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape:
            self.hide()
        else:
            super().keyPressEvent(e)

    # ---------- chat ----------
    def add_line(self, who, text, color):
        import html
        self.log.append(
            f'<div style="margin:4px 0;"><b style="color:{color}">{who}:</b> '
            f'{html.escape(text).replace(chr(10), "<br>")}</div>')

    def send(self):
        text = self.input.text().strip()
        if not text or (self.worker and self.worker.isRunning()):
            return
        self.add_line("Bạn", text, "#ffd54f")
        self.input.clear()
        self.input.setEnabled(False)
        self.input.setPlaceholderText(f"{PET_NAME} đang nghĩ (có thể đang tra web)...")
        self.add_line(PET_NAME, "đang nghĩ…", "#888")                  # báo là đã nhận tin, đang xử lý
        self.worker = VerityWorker(text)
        self.worker.done.connect(self.on_reply)
        self.worker.finished.connect(self._unlock)     # dự phòng: thread kết thúc là mở khóa ô nhập
        self.worker.start()

    def _unlock(self):
        self.input.setEnabled(True)
        self.input.setPlaceholderText("Nói gì đó với {0}... (Enter để gửi)".format(PET_NAME))
        self.input.setFocus()

    def on_reply(self, user_text, response):
        self.add_line(PET_NAME, response, "#4fc3f7")
        self._unlock()                                   # mở ô nhập ngay, việc lưu trí nhớ để sau
        if self.pet is not None:
            self.pet.talk_for(min(12.0, max(2.5, len(response) * 0.06)))   # nhe răng khi trả lời
        # chỉ lưu trí nhớ nếu Ai_bot đã được nạp sẵn (không import mới ở đây vì có thể làm đơ giao diện)
        try:
            mod = sys.modules.get("Ai_bot")
            if mod is not None and hasattr(mod, "memory"):
                mod.memory.add(user_text, response)
                mod.memory.save()
        except Exception as ex:
            try:
                print(f"[quickchat] lưu trí nhớ lỗi: {ex}")
            except Exception:
                pass


class Pet(QWidget):
    def __init__(self, open_chat_cb=None):
        super().__init__()
        self.open_chat_cb = open_chat_cb

        # cửa sổ trong suốt, không viền, luôn nằm trên cùng, không hiện trên taskbar
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.resize(SIZE, SIZE)

        self.screen_rect = QApplication.primaryScreen().availableGeometry()
        self.sprites = self._load_sprites()
        self.face = self._load_face()
        self.talking_until = 0.0
        self.roll = 0.0                                   # góc lăn (độ)
        self.next_quip = time.time() + random.randint(QUIP_MIN, QUIP_MAX)

        self.state = "fall"
        self.dir = random.choice([-1, 1])   # -1 trái, 1 phải
        self.vy = 0
        self.frame = 0
        self.tick = 0
        self.state_timer = 0
        self.dragging = False
        self.drag_offset = QPoint()

        self.move(random.randint(self.left_limit(), self.right_limit()),
                  self.screen_rect.top())

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_pet)
        self.timer.start(1000 // FPS)

        # bong bóng thoại + nhìn màn hình
        self.bubble = Bubble()
        self.watcher = ScreenWatcher()
        self.watcher.comment.connect(self.on_watch_comment)
        self.chat = QuickChat()
        self.press_pos = None
        self.moved = False
        self.prev_state = "idle"
        self.watcher.start()
        QApplication.instance().aboutToQuit.connect(self.watcher.stop)

    def moveEvent(self, e):
        if hasattr(self, 'bubble') and self.bubble.isVisible():
            self.bubble.follow(self)
        if hasattr(self, 'chat') and self.chat.isVisible():
            self.chat.follow(self)
        super().moveEvent(e)

    # ---------- giới hạn màn hình ----------
    def left_limit(self):
        return self.screen_rect.left()

    def right_limit(self):
        return self.screen_rect.right() - SIZE

    def floor_y(self):
        return self.screen_rect.bottom() - SIZE

    # ---------- sprite ----------
    def _load_sprites(self):
        sprites = {}
        folder = os.path.join(HERE, "sprites")
        for name in ["walk", "idle", "climb", "fall", "drag"]:
            frames = []
            for i in range(8):
                p = os.path.join(folder, f"{name}_{i}.png")
                if os.path.exists(p):
                    frames.append(QPixmap(p).scaled(
                        SIZE, SIZE, Qt.AspectRatioMode.KeepAspectRatio,
                        Qt.TransformationMode.SmoothTransformation))
            sprites[name] = frames
        return sprites

    def _load_face(self):
        face = {}
        for name in ("smile", "talk"):
            p = next((c for c in (os.path.join(HERE, "sprites", f"{name}.png"),
                                  os.path.join(HERE, f"{name}.png"))
                      if os.path.exists(c)), None)
            if p:
                face[name] = QPixmap(p).scaled(
                    SIZE, SIZE, Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation)
        return face if len(face) == 2 else {}

    def talk_for(self, seconds):
        """Nhe răng trong `seconds` giây."""
        self.talking_until = max(self.talking_until, time.time() + seconds)
        self.update()

    def is_talking(self):
        return time.time() < self.talking_until

    # ---------- vòng lặp chính ----------
    def update_pet(self):
        self.tick += 1
        if self.tick % 6 == 0:
            self.frame += 1

        if self.dragging:
            return

        # đang mở khung chat thì pet đứng yên (trừ khi đang rơi)
        if self.chat.isVisible() and self.state != "fall":
            self.update()
            return

        x, y = self.x(), self.y()

        if self.state != "walk":
            # hết lăn thì xoay từ từ về thẳng đứng
            r = self.roll % 360
            if r > 180:
                r -= 360
            self.roll = r * 0.85 if abs(r) > 0.5 else 0.0

        # tự lảm nhảm khi rảnh
        if time.time() >= self.next_quip:
            self.next_quip = time.time() + random.randint(QUIP_MIN, QUIP_MAX)
            if not self.bubble.isVisible():
                self.bubble.say(random.choice(QUIPS), self)

        if self.state == "fall":
            self.vy += GRAVITY
            y += self.vy
            if y >= self.floor_y():
                y = self.floor_y()
                self.vy = 0
                self.set_state("idle")
            self.move(x, y)

        elif self.state == "idle":
            self.state_timer -= 1
            if self.state_timer <= 0:
                self.dir = random.choice([-1, 1])
                self.set_state("walk")

        elif self.state == "walk":
            x += self.dir * WALK_SPEED
            # lăn: quay đúng bằng quãng đường đã đi (chu vi = pi * SIZE)
            self.roll += self.dir * WALK_SPEED * 360 / (math.pi * SIZE)
            self.state_timer -= 1
            # chạm mép màn hình -> leo tường hoặc quay đầu
            if x <= self.left_limit() or x >= self.right_limit():
                x = max(self.left_limit(), min(x, self.right_limit()))
                if random.random() < 0.6:
                    self.set_state("climb")      # leo lên
                else:
                    self.dir *= -1
            elif self.state_timer <= 0:
                self.set_state("idle")
            self.move(x, y)

        elif self.state == "climb":
            y -= CLIMB_SPEED
            self.state_timer -= 1
            if y <= self.screen_rect.top() or self.state_timer <= 0:
                # leo xong thì buông tay rơi xuống
                self.dir = 1 if x <= self.left_limit() else -1
                self.set_state("fall")
            self.move(x, max(y, self.screen_rect.top()))

        self.update()

    def set_state(self, state):
        self.state = state
        self.frame = 0
        if state == "idle":
            self.state_timer = random.randint(FPS * 1, FPS * 4)
        elif state == "walk":
            self.state_timer = random.randint(FPS * 3, FPS * 8)
        elif state == "climb":
            self.state_timer = random.randint(FPS * 2, FPS * 6)

    # ---------- vẽ ----------
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        key = "drag" if self.dragging else self.state
        frames = self.sprites.get(key) or []

        # xoay/lật theo hướng và trạng thái
        p.translate(SIZE / 2, SIZE / 2)
        if self.state == "climb":
            p.rotate(90 if self.x() <= self.left_limit() else -90)
        if self.face:
            if self.state != "climb":
                p.rotate(self.roll)              # lăn tròn theo hướng đi
        elif self.dir > 0 and self.state != "climb":
            p.scale(-1, 1)
        p.translate(-SIZE / 2, -SIZE / 2)

        if self.face:
            p.drawPixmap(0, 0, self.face["talk" if self.is_talking() else "smile"])
        elif frames:
            p.drawPixmap(0, 0, frames[self.frame % len(frames)])
        else:
            self._draw_placeholder(p, key)

    def _draw_placeholder(self, p, key):
        """Hình tạm khi chưa có sprite."""
        bob = 3 if (key in ("walk", "climb") and self.frame % 2) else 0
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#4fc3f7"))
        p.drawEllipse(QRectF(14, 20 + bob, 68, 66))           # thân
        p.setBrush(QColor("white"))
        p.drawEllipse(QRectF(30, 38 + bob, 14, 16))           # mắt trái
        p.drawEllipse(QRectF(54, 38 + bob, 14, 16))           # mắt phải
        p.setBrush(QColor("#111"))
        p.drawEllipse(QRectF(35, 44 + bob, 6, 8))
        p.drawEllipse(QRectF(59, 44 + bob, 6, 8))
        # chân
        p.setBrush(QColor("#0288d1"))
        off = 4 if (key == "walk" and self.frame % 2) else 0
        p.drawEllipse(QRectF(24 + off, 80, 18, 12))
        p.drawEllipse(QRectF(56 - off, 80, 18, 12))

    # ---------- chuột ----------
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.press_pos = e.globalPosition().toPoint()
            self.drag_offset = self.press_pos - self.pos()
            self.prev_state = self.state
            self.moved = False
            self.dragging = True

    def mouseMoveEvent(self, e):
        if self.dragging:
            gp = e.globalPosition().toPoint()
            if not self.moved and (gp - self.press_pos).manhattanLength() > 6:
                self.moved = True            # vượt ngưỡng -> là kéo thả, không phải click
                self.update()
            if self.moved:
                self.move(gp - self.drag_offset)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and self.dragging:
            self.dragging = False
            if self.moved:
                self.vy = 0
                self.set_state("fall")       # kéo xong thì thả rơi
            else:
                self.state = self.prev_state  # chỉ là click: giữ nguyên trạng thái
                self.toggle_chat()
            self.update()

    def toggle_chat(self):
        if self.chat.isVisible():
            self.chat.hide()
        else:
            self.bubble.hide()
            self.chat.open_for(self)

    def on_watch_comment(self, text):
        if self.chat.isVisible():
            self.chat.add_line(f"{PET_NAME} (nhìn màn hình)", text, "#a5d6a7")
        else:
            self.bubble.say(text, self)

    def toggle_watch(self):
        self.watcher.enabled = not self.watcher.enabled
        self.bubble.say("Được thôi... tao đang nhìn mày đây." if self.watcher.enabled
                        else "Được rồi, tao nhắm mắt. Chỉ một chút thôi nhé.", self, 3)

    def contextMenuEvent(self, e):
        menu = QMenu(self)
        chat = QAction("Mở app chat đầy đủ", self)
        chat.triggered.connect(lambda: self.open_chat_cb and self.open_chat_cb())
        quit_ = QAction("Thoát", self)
        quit_.triggered.connect(QApplication.instance().quit)
        look = QAction("Nhìn màn hình: BẬT" if self.watcher.enabled else "Nhìn màn hình: TẮT", self)
        look.triggered.connect(self.toggle_watch)
        menu.addAction(chat)
        menu.addAction(look)
        menu.addAction(quit_)
        menu.exec(e.globalPos())


def main():
    os.chdir(HERE)                      # để dùng chung bot_memory.json, settings.json với Ai_bot.py
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)   # đóng chat không tắt pet

    holder = {"win": None}

    def open_chat():
        # import lúc cần để pet chạy nhanh, và dùng lại đúng class chat của mày
        from Ai_bot import AiBotGUI
        if holder["win"] is None or not holder["win"].isVisible():
            holder["win"] = AiBotGUI()
        holder["win"].show()
        holder["win"].raise_()
        holder["win"].activateWindow()

    pet = Pet(open_chat_cb=open_chat)
    pet.show()
    # vừa xuất hiện là chào luôn (trễ 1 giây cho cửa sổ hiện xong)
    QTimer.singleShot(1000, lambda: pet.bubble.say(GREETING, pet, 9))
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
