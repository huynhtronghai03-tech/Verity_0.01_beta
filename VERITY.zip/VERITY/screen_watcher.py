"""
screen_watcher.py - cho Harris "nhìn" màn hình rồi bình luận.

Tầng 1 (mặc định, nhẹ): đọc tiêu đề cửa sổ đang mở (chỉ Windows) -> llama3.2 nói 1 câu liên quan.
Tầng 2 (tùy chọn, USE_VISION=True): chụp màn hình -> model ảnh nhỏ mô tả -> llama3.2 bình luận.
    Cần:  pip install pillow   và   ollama pull moondream
Mọi thứ chạy LOCAL qua Ollama, không gửi gì ra internet.
"""
import io
import re
import sys
import time
import ctypes

import ollama
from PyQt6.QtCore import QThread, pyqtSignal

TEXT_MODEL = "llama3.2"
VISION_MODEL = "moondream"      # nhẹ (~1.7GB), hợp máy RAM ít
USE_VISION = False              # bật True nếu muốn nó nhìn ảnh thật

CHECK_EVERY = 3                 # giây: kiểm tra cửa sổ đang mở
COMMENT_COOLDOWN = 20           # giây: tối thiểu giữa 2 lần nói
IGNORE_TITLES = [               # đừng bình luận cửa sổ của chính mình / cửa sổ terminal
    "harris", "verity", "py.exe", "python.exe", "pythonw", "cmd.exe",
    "command prompt", "powershell", "windows terminal",
]
GENERIC_TITLES = {              # tiêu đề hệ thống vô nghĩa (so khớp nguyên văn)
    "program manager", "task switching", "search", "start", "settings",
    "system tray overflow window.", "windows input experience",
}

# Gặp mấy từ này trong tiêu đề thì im lặng, không chụp, không hỏi AI (riêng tư)
PRIVATE_WORDS = [
    "password", "mật khẩu", "bank", "ngân hàng", "vietcombank", "techcombank",
    "momo", "paypal", "login", "đăng nhập", "sign in", "incognito", "ẩn danh",
    "private browsing", "otp", "2fa", "wallet", "ví ",
]

from verity_brain import WATCH_PERSONA as PERSONA, is_busy   # tính cách Verity


def get_active_window_title():
    if sys.platform != "win32":
        return ""
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        n = user32.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return ""
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        return buf.value.strip()
    except Exception:
        return ""


def is_private(text):
    t = text.lower()
    return any(w in t for w in PRIVATE_WORDS)


def describe_screen():
    """Chụp màn hình và nhờ model ảnh mô tả ngắn. Trả về '' nếu lỗi."""
    try:
        from PIL import ImageGrab
        img = ImageGrab.grab()
        img.thumbnail((768, 768))
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        r = ollama.chat(
            model=VISION_MODEL,
            messages=[{
                "role": "user",
                "content": "Describe briefly what is on this computer screen "
                           "(app, website, game, document, topic).",
                "images": [buf.getvalue()],
            }],
        )
        return r["message"]["content"].strip()
    except Exception as e:
        print(f"[watcher] vision lỗi: {e}")
        return ""


def make_comment(title, scene):
    info = f"Người kia đang mở cửa sổ có tiêu đề: {title}"
    if scene:
        info += f"\nMô tả màn hình: {scene}"
    info += ("\n\nHãy nói 1-2 câu cà khịa trực tiếp với họ (xưng tao, gọi mày). "
             "Nếu không hiểu đây là gì thì trả lời đúng một từ: SKIP.")
    try:
        r = ollama.chat(
            model=TEXT_MODEL,
            messages=[
                {"role": "system", "content": PERSONA},
                {"role": "user", "content": info},
            ],
            options={"temperature": 0.7, "num_predict": 90},
        )
        text = r["message"]["content"].strip().strip('"')
    except Exception as e:
        print(f"[watcher] llm lỗi: {e}")
        return ""
    if not text or re.search(r"\bskip\b", text, re.I) and len(text) < 30:
        return ""
    text = re.sub(r"\bchủ( nhân)?\b", "mày", text, flags=re.I)   # model hay lỡ miệng gọi 'chủ'
    return text


class ScreenWatcher(QThread):
    comment = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.enabled = True
        self._running = True
        self._last_title = ""
        self._last_spoke = 0.0

    def stop(self):
        self._running = False

    def run(self):
        while self._running:
            time.sleep(CHECK_EVERY)
            if not self.enabled:
                continue

            if is_busy():           # đang chat thì đừng tranh Ollama
                continue
            title = get_active_window_title()
            if not title or title == self._last_title:
                continue
            low = title.lower()
            if low in GENERIC_TITLES or any(w in low for w in IGNORE_TITLES):
                continue
            self._last_title = title

            if is_private(title):
                continue
            if time.time() - self._last_spoke < COMMENT_COOLDOWN:
                continue

            scene = describe_screen() if USE_VISION else ""
            if USE_VISION and is_private(scene):
                continue

            text = make_comment(title, scene)
            if text and self._running and self.enabled:
                self._last_spoke = time.time()
                self.comment.emit(text)
